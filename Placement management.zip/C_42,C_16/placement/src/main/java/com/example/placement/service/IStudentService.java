package com.example.placement.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import com.example.placement.entities.Student;
import com.example.placement.repository.IStudentRepository;


 public class IStudentService {
	@Autowired 
    private IStudentRepository repo; 
      
    public List<Student> listAll()  
    { 
        return repo.findAll(); 
    }       
    public void save(Student student)  
    { 
        repo.save(student); 
    }       
    public Student get(Integer id)  
    { 
        return repo.findById(id).get(); 
    }       
    public void delete(Integer id)  
    { 
        repo.deleteById(id); 
    } 
}
