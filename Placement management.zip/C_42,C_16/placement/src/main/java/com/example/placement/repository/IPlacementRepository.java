package com.example.placement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.placement.entities.Placement;


public interface IPlacementRepository extends JpaRepository<Placement, Integer> {



}
