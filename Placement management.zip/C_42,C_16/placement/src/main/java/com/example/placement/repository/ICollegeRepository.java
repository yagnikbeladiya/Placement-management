package com.example.placement.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.placement.entities.College;

public interface ICollegeRepository extends JpaRepository<College, Integer> {



}
