package com.example.placement.exceptions;

public class InvalidUserNameOrPasswordException extends Exception {

}
