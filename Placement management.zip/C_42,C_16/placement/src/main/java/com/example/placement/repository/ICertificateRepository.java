package com.example.placement.repository;



import com.example.placement.entities.Certificate;

import org.springframework.data.jpa.repository.JpaRepository;


public interface ICertificateRepository extends JpaRepository<Certificate, Integer> {

}
