package com.example.placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.placement.entities.Placement;
import com.example.placement.repository.IPlacementRepository;


public class IPlacementService {
	@Autowired 
    private IPlacementRepository repo; 
      
    public List<Placement> listAll()  
    { 
        return repo.findAll(); 
    }       
    public void save(Placement placement)  
    { 
        repo.save(placement); 
    }       
    public Placement get(Integer id)  
    { 
        return repo.findById(id).get(); 
    }       
    public void delete(Integer id)  
    { 
        repo.deleteById(id); 
    } 
	
}
