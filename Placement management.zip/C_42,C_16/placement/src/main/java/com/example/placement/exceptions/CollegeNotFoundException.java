package com.example.placement.exceptions;

public class CollegeNotFoundException extends Exception {

}
