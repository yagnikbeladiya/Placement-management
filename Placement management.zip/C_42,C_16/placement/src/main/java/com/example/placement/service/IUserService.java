package com.example.placement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.placement.entities.User;
import com.example.placement.repository.IUserRepository;



public class IUserService {
	@Autowired 
    private IUserRepository repo; 
      
    public List<User> listAll()  
    { 
        return repo.findAll(); 
    }       
    public void save(User user)  
    { 
        repo.save(user); 
    }       
    public User get(Integer id)  
    { 
        return repo.findById(id).get(); 
    }       
    public void delete(Integer id)  
    { 
        repo.deleteById(id); 
    } 
}
