package com.example.placement.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.placement.entities.College;

import com.example.placement.repository.ICollegeRepository;

@Service 
@Transactional
public class ICollegeService 
{
	@Autowired 
	private ICollegeRepository repo; 
      
    public List<College> listAll()  
    { 
        return repo.findAll(); 
    }       
    public void save(College clg)  
    { 
        repo.save(clg); 
    }       
    public College get(Integer id)  
    { 
        return repo.findById(id).get(); 
    }       
    public void delete(Integer id)  
    { 
        repo.deleteById(id); 
    } 
}
