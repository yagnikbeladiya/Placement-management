package com.example.placement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.placement.entities.Student;


public interface IStudentRepository extends JpaRepository<Student, Integer> {


}
