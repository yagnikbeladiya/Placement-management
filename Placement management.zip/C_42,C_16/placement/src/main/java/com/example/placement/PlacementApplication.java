package com.example.placement;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.placement.entities.Admin;
import com.example.placement.entities.Certificate;
import com.example.placement.entities.College;
import com.example.placement.entities.Placement;
import com.example.placement.entities.Student;
import com.example.placement.entities.User;
import com.example.placement.service.AdminService;
import com.example.placement.service.CertificateService;
import com.example.placement.service.ICollegeService;
import com.example.placement.service.IPlacementService;
import com.example.placement.service.IStudentService;
import com.example.placement.service.IUserService;

@SpringBootApplication
public class PlacementApplication {

	public static void main(String[] args) {
		var context=SpringApplication.run(PlacementApplication.class, args);
		Admin ad=new Admin();
		ad.setId(2);
		ad.setName("kishan");
		ad.setPassword("chavda");
		AdminService as=context.getBean(AdminService.class);
		as.save(ad);
		
		User user=new User();
		user.setId(1);
		user.setName("raju");
		user.setPassword("raju@123");
		user.setType("Teacher");
		IUserService us=context.getBean(IUserService.class);
		us.save(user);
		
		College college=new College();
		college.setId(1);
		college.setCollegeName("LJ College");
		college.setCollegeAdmin(user);
		ICollegeService cs=context.getBean(ICollegeService.class);
		cs.save(college);
		
		
		Certificate c=new Certificate();
		c.setId(1);
		c.setYear(2024);
		c.setCollege(college);
		CertificateService certificate=context.getBean(CertificateService.class);
		certificate.save(c);
		
	 
		LocalDate date=LocalDate.now(); 
		Placement placement=new Placement();
		placement.setId(1);
		placement.setName("java developer");
		placement.setCollege(college);
		placement.setDate(date);
		placement.setQualification("MCA");
		placement.setYear(2025);
		IPlacementService sp=context.getBean(IPlacementService.class);
		sp.save(placement);
		
		
		Student student=new Student();
		student.setId(1);
		student.setName("Milesh");
		student.setCollege(college);
		student.setQualification("BCA");
		student.setRoll(10);
		student.setCourse("Java");
		student.setYear(2025);
		student.setCertificate(c);
		student.setHallTicketNo(1);
		IStudentService ss=context.getBean(IStudentService.class);
		ss.save(student);
		
		
	
	}
}
